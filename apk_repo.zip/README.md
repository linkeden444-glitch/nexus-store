﻿# NEXUS UC Store - Android APK Client (64-Bit arm64-v8a)

Production-ready Kivy Android deployment client.

## Repository Contents
- .github/workflows/main.yml: Automated GitHub Actions pipeline for compiling the pure 64-bit APK (rm64-v8a).
- main.py: Full client source code with offline capability, hardware lock, dynamic server gateway, stealth download, and ZIP extraction.
- uildozer.spec: Verified Buildozer specification targeting API 33 and ARM64-v8a architecture.
- icon.png: Official launcher and presplash icon.
- equirements.txt: Python package requirements.

## How to Build APK via GitHub Actions
1. Push this repository to GitHub (or create a new GitHub repo and push these files).
2. Open your repository on GitHub and click the **Actions** tab.
3. Select **"🚀 Build Android APK (NEXUS UC Store Automated Pipeline)"**.
4. Click **"Run workflow"** -> **"Run workflow"**.
5. Once the build finishes (~10-15 mins), download the artifact **"NEXUS-UC-Store-v3.0.0-ARM64-64bit-APK"** which contains your clean, native 64-bit .apk!
